
struct Temperature {
    var celsius: Double
      
    init(celsius: Double) {
        self.celsius = celsius
    }
      
    init(fahrenheit: Double) {
        celsius = (fahrenheit - 32) / 1.8
    }
}
 
let currentTemperature = Temperature(celsius: 18.5)
let boiling = Temperature(fahrenheit: 212.0)
 
print(currentTemperature.celsius)
print(boiling.celsius)

