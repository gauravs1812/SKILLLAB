struct Car {
    
    var  make : String
    var year : Int
    var colour : String
    
    
    func startEngine(){
        print("THE Engine is \(year)")
    }
    
    func drive(){
        print("The car is \(make)")
    }
    
    func park(){
    }
    
    func steer
    (){
        print("colour of steering is \(colour)")
    }
}
let firstCar = Car(make: "Honda", year: 2010, colour: "blue")
let second = Car(make : "TOYOTA", year : 2012 ,colour: "red")
firstCar.startEngine()
firstCar.drive()
