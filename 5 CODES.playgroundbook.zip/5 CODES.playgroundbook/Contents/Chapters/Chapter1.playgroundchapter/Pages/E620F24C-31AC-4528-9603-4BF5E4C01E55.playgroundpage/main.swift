struct size
{
    var width:Double
    var height:Double
    func area()->Double {
        return width * height
    }
    
}
var someSize = size(width: 10.0, height: 5.5)
let area  = someSize.area()
print(area)
